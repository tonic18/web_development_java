package c04_operator;
    /*
        패키지명은 소문자, 클래스명은 대문자로 시작
     */
public class Operator01 {
        public static void main(String[] args) {

//            int i = 10; // 변수 선언 및 초기화
//            System.out.println(i);
            // 대입 연산자 : '=' -> 오른쪽의 데이터를 = 왼쪽의 변수에 대입한다는 의미
//            i = i + 1;
//            System.out.println(i);
            // 복합 대입 연산자
            /*
                1) +=
                2) -=
                3) *=
                4) /=
             */
//            int num = 1;
//            System.out.println(num);
//            num +=2; // num = num + 2;
//            System.out.println(num);
//            num -=1; // num = num - 1;
//            System.out.println(num);
//            num *=10; // num = num * 10;
//            System.out.println(num);
//            num /=5; // num = num / 5;
//            System.out.println(num);
//            int j = 10;
//            System.out.println(j);
//            System.out.println(j++); // 변수++ : 해당 코드를 실행시킨 후에 변수에 1을 더할 것
//            System.out.println(j);
//            System.out.println(++j); // ++변수 : 해당 코드를 실행시키기 전에 변수에 1을 더할 것
//            System.out.println(j);
//            System.out.println(--j);
//            System.out.println(j--);
              /*
                일반 수식 연산자
                + : 더하기
                - : 빼기
                * : 곱하기
                / : 나누기
                % : 나머지 : return값은 int
               */
        }
}
