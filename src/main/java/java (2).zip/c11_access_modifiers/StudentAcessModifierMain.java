package c11_access_modifiers;

public class StudentAcessModifierMain {
    public static void main(String[] args) {
        StudentAccessModifier studentAccessModifier1 = new StudentAccessModifier();
        StudentAccessModifier studentAccessModifier2 = new StudentAccessModifier();
        StudentAccessModifier studentAccessModifier3 = new StudentAccessModifier();
    }
}
