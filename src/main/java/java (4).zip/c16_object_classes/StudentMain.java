package c16_object_classes;

public class StudentMain {
}
