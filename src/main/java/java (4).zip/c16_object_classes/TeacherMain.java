package c16_object_classes;

public class TeacherMain {
    public static void main(String[] args) {

    }
}
