package c09_classes;

public class ClassA {

    // 멤버 변수
    int num;
    String name;
    double score;

    void callName(){
        System.out.println(name + "을(를) 부릅니다.");
    }
}
