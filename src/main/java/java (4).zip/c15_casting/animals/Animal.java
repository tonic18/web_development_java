package c15_casting.animals;

public class Animal {

    public void makeSound() {
        System.out.println("동물이 소리를 냅니다.");
    }

}
