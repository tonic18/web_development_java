package c14_abstraction.interfaces;

public interface Down {
    void onDown();
}
